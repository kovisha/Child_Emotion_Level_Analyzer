import logging

import pandas as pd
import pickle as pkl
import numpy as np
import matplotlib.pyplot as plt


# Define function to predict the emotion level according to age category

def predictEmoLevel(category, csvpath):
    if category == "1":

        # Import RF model for Overall Child Analysis

        SVMModelHT = 'Models\\Overall\\SVMPredictionModel.pkl'
        Predictions = []  # Save predictions as a list

        # Read pickle converted csv file containing all features.

        data = pd.read_csv(csvpath)

        # Extract input features for the model

        testdata = data[
            [" AU01_r", " AU02_r", " AU05_r", " AU04_r", " AU15_r", " AU06_r", " AU07_r", " AU10_r", " AU12_r",
             " AU25_r",
             " AU09_r", " AU17_r"]]

        # Open the RF model for Emotion level prediction

        loaded_model = pkl.load(open(SVMModelHT, 'rb'))

        # Predictions stored as a list

        Predictions = loaded_model.predict(testdata)

        # Final dataframe creation with frame number and predicted emotion level.

        RFdf = pd.DataFrame(Predictions, columns=['Prediction'])

        RFdf['Frame'] = np.arange(len(RFdf))

        # Plot the emotion level predictions

        fig, ax = plt.subplots(figsize=(12, 6), dpi=100)

        plt.plot(RFdf['Frame'], RFdf["Prediction"], color='blue', label="Predicted Emotion level")
        plt.xlabel("Frame")
        plt.ylabel("Emotion Level")
        plt.legend()
        plt.savefig("Plots\\Overall\\S1_happy_1_SVMModelHT_OverallModel.png")

    elif category == "2":

        # Import RF model for 4-6 years Child Analysis

        SVMModelHT = 'Models\\4-6Years\\SVMPredictionModelHypertuned(4-6).pkl'

        Predictions = []  # Save predictions as a list

        # Read pickle converted csv file containing all features.

        data = pd.read_csv(csvpath)

        # Extract input features for the model

        testdata = data[
            [" AU01_r", " AU02_r", " AU05_r", " AU04_r", " AU15_r", " AU06_r", " AU07_r", " AU10_r", " AU12_r",
             " AU25_r",
             " AU09_r", " AU17_r"]]

        # Open the RF model for Emotion level prediction

        loaded_model = pkl.load(open(SVMModelHT, 'rb'))

        # Predictions stored as a list

        Predictions = loaded_model.predict(testdata)

        # Final dataframe creation with frame number and predicted emotion level.

        RFdf = pd.DataFrame(Predictions, columns=['Prediction'])

        RFdf['Frame'] = np.arange(len(RFdf))

        # Plot the emotion level predictions

        fig, ax = plt.subplots(figsize=(12, 6), dpi=100)

        plt.plot(RFdf['Frame'], RFdf["Prediction"], color='blue', label="Predicted Emotion level")
        plt.xlabel("Frame")
        plt.ylabel("Emotion Level")
        plt.legend()
        plt.savefig("Plots\\4-6Years\\S1_happy_1_SVMModelHT_4-6Years.png")

    elif category == "3":

        # Import RF model for 6-10 Years Child Analysis

        SVMModelHT = 'Models\\6-10Years\\SVMPredictionModelHypertuned(6-10)withNeutral.pkl'

        Predictions = []  # Save predictions as a list

        # Read pickle converted csv file containing all features.

        data = pd.read_csv(csvpath)

        # Extract input features for the model

        testdata = data[
            [" AU01_r", " AU02_r", " AU05_r", " AU04_r", " AU15_r", " AU06_r", " AU07_r", " AU10_r", " AU12_r",
             " AU25_r",
             " AU09_r", " AU17_r"]]

        # Open the RF model for Emotion level prediction

        loaded_model = pkl.load(open(SVMModelHT, 'rb'))

        # Predictions stored as a list

        Predictions = loaded_model.predict(testdata)

        # Final dataframe creation with frame number and predicted emotion level.

        RFdf = pd.DataFrame(Predictions, columns=['Prediction'])

        RFdf['Frame'] = np.arange(len(RFdf))

        # Plot the emotion level predictions

        fig, ax = plt.subplots(figsize=(12, 6), dpi=100)

        plt.plot(RFdf['Frame'], RFdf["Prediction"], color='blue', label="Predicted Emotion level")
        plt.xlabel("Frame")
        plt.ylabel("Emotion Level")
        plt.legend()
        plt.savefig("Plots\\6-10Years\\S1_happy_1_SVMModelHT_6-10Years.png")

    else:
        logging.error("Program exited! Check the inputs and retry")
