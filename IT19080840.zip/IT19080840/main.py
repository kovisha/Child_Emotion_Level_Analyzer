# Import necessary libraries.

import argparse
from argparse import RawTextHelpFormatter

import os
import cv2

os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

# Import controller to merge AU.
from controller import auMerger

# Define the function to capture media.

def videocapture(videopath):

    capture = cv2.VideoCapture(videopath)
    print("Video path recognized,Proceeding for frame capture")

    def getvideoframe(second):
        capture.set(cv2.CAP_PROP_POS_MSEC, second * 1000)
        hasFrames, image = capture.read()
        print("Proceed frame separation")

        if hasFrames:
            print("Frames present")
            cv2.imwrite('mediaFiles/videoFrames/frame_'+str(second)+' .jpg', image)  # save frame as JPG file
        return hasFrames

    second = 0

    # Initialise frame rate for frame separation
    frameRate = 0.1

    success = getvideoframe(second)
    while success:
        second = second + frameRate
        second = round(second, 2)
        success = getvideoframe(second)
        print("Frames are obtained")


# define a function to generate csv files using open face - PENDING
# The created files should be written to folder AUFiles


# ---------------------------------- Begin main method implementation  -------------------------------------------- #

if __name__ == '__main__':

    # Pass data capture parameters through a parser.

    parser = argparse.ArgumentParser(description='test', formatter_class=RawTextHelpFormatter)
    parser.add_argument("mode", help="select a method among 'image', 'video' or 'webcam' to run ESR-9.",
                        type=str, choices=["image", "video", "webcam"])

    parser.add_argument("-i", "--input", help="define the full path to an image or video.",
                        type=str)

    args = parser.parse_args()

# Invoke the main method to accept parameters.

    if args.mode == "video":
        try:
            videocapture(args.input)
        except RuntimeError as e:
            print(e)

    # Call function to merge the AU files and create final file.

    auMerger.csvMerger()

    # Initiate Clustering algorithm once final AU file is generated.

    auMerger.clusterInitiation()
