# Import libraries.

import pandas as pd
from matplotlib import pyplot as plt
from sklearn.cluster import KMeans

# Define the K means algorithm to cluster happy frames of video.
def happyclusteralgorithm():
    df = pd.read_csv("FinalVideoAU.csv")
    df.head()

    sse = []
    k_rng = range(1, 10)

    for k in k_rng:
        # in each iteration create a new model with clusters = k
        km = KMeans(n_clusters=k)

        # Cluster using EFA AU showing variation for Happy emotion levels.
        km.fit(df[['AU06_r', 'AU07_r', 'AU10_r', 'AU12_r', 'AU25_r']])

        # inertia will give the sse
        sse.append(km.inertia_)

        # Visualize elbow variations to evaluate the number of clusters.
        def plotElbow():
            plt.xlabel('K')
            plt.ylabel('Sum of squared error')
            plt.plot(k_rng, sse)
    plotElbow()

    km = KMeans(3)
    km
    y_predicted = km.fit_predict(df[['AU06_r', 'AU07_r', 'AU10_r', 'AU12_r', 'AU25_r']])
    label = km.predict(df[['AU06_r', 'AU07_r', 'AU10_r', 'AU12_r', 'AU25_r']])
    y_predicted

    df['cluster'] = y_predicted

    dwn = df[['Result', 'AU06_r', 'AU07_r', 'AU10_r', 'AU12_r', 'AU25_r', 'cluster']].copy()
    dwn.to_csv('HappyEmotionClustered.csv')

    # Visualize the variations of Happy AU with emotion levels.

    def plot_variations():
        # create figure and axis objects with subplots()
        fig, ax = plt.subplots()
        # make a plot
        ax.plot(df['Result'], df["AU06_r"], color="red", label='AU06')
        ax.plot(df['Result'], df["AU07_r"], color="yellow", label='AU07')
        ax.plot(df['Result'], df["AU10_r"], color="green", label='AU10')
        ax.plot(df['Result'], df["AU12_r"], color="cyan", label='AU12')
        ax.plot(df['Result'], df["AU25_r"], color="magenta", label='AU25')
        # set x-axis label
        ax.set_xlabel("Frame", fontsize=14)
        # set y-axis label
        ax.set_ylabel("AU Intensity", color="red", fontsize=14)

        plt.legend()

        # twin object for two different y-axis on the sample plot
        ax2 = ax.twinx()
        # make a plot with different y-axis using second axis object
        ax2.plot(df['Result'], df["cluster"], color="blue", marker="o")
        ax2.set_ylabel("Emotion Level", color="blue", fontsize=14)
        plt.show()
        # save the plot as a file
        fig.savefig('HappyVariation_plot.jpg',
                    format='jpeg',
                    dpi=100,
                    bbox_inches='tight')
    plot_variations()

# Define the K means algorithm to cluster sad frames of video.

def sadclusteralgorithm():
    df = pd.read_csv("FinalVideoAU.csv")
    df.head()

    sse = []
    k_rng = range(1, 10)
    # just going through 1 to 9
    for k in k_rng:
        # in each iteration create a new model with clusters = k
        km = KMeans(n_clusters=k)

        # Cluster using EFA AU showing variation for sad emotion levels.
        km.fit(df[['AU01_r', 'AU04_r', 'AU15_r']])

        # inertia will give the sse
        sse.append(km.inertia_)

        # Visualize elbow variations to evaluate the number of clusters.

        def plotElbow():
            plt.xlabel('K')
            plt.ylabel('Sum of squared error')
            plt.plot(k_rng, sse)
    plotElbow()

    km = KMeans(3)
    km
    y_predicted = km.fit_predict(df[['AU01_r', 'AU04_r', 'AU15_r']])
    label = km.predict(df[['AU01_r', 'AU04_r', 'AU15_r']])
    y_predicted

    df['cluster'] = y_predicted

    dwn = df[['Result', 'AU01_r', 'AU04_r', 'AU15_r', 'cluster']].copy()
    dwn.to_csv('SadEmotionClustered.csv')

    # Visualize the variations of Sad AU with emotion levels.

    def plot_variations():
        # create figure and axis objects with subplots()
        fig, ax = plt.subplots()
        # make a plot
        ax.plot(df['Result'], df["AU01_r"], color="red", label='AU01')
        ax.plot(df['Result'], df["AU04_r"], color="yellow", label='AU04')
        ax.plot(df['Result'], df["AU15_r"], color="green", label='AU15')

        # set x-axis label
        ax.set_xlabel("Frame", fontsize=14)
        # set y-axis label
        ax.set_ylabel("AU Intensity", color="red", fontsize=14)

        plt.legend()

        # twin object for two different y-axis on the sample plot
        ax2 = ax.twinx()
        # make a plot with different y-axis using second axis object
        ax2.plot(df['Result'], df["cluster"], color="blue", marker="o")
        ax2.set_ylabel("Emotion Level", color="blue", fontsize=14)
        plt.show()
        # save the plot as a file
        fig.savefig('SadVariation_plot.jpg',
                    format='jpeg',
                    dpi=100,
                    bbox_inches='tight')

    plot_variations()

# Define the K means algorithm to cluster disgust frames of video.

def disgustclusteralgorithm():
    df = pd.read_csv("FinalVideoAU.csv")
    df.head()

    sse = []
    k_rng = range(1, 10)
    # just going through 1 to 9
    for k in k_rng:
        # in each iteration create a new model with clusters = k
        km = KMeans(n_clusters=k)

        # Cluster using EFA AU showing variation for disgust emotion levels.
        km.fit(df[['AU09_r', 'AU10_r', 'AU17_r']])

        # inertia will give the sse
        sse.append(km.inertia_)

        # Visualize elbow variations to evaluate the number of clusters.

        def plotElbow():
            plt.xlabel('K')
            plt.ylabel('Sum of squared error')
            plt.plot(k_rng, sse)
    plotElbow()

    km = KMeans(3)
    km
    y_predicted = km.fit_predict(df[['AU09_r', 'AU10_r', 'AU17_r']])
    label = km.predict(df[['AU09_r', 'AU10_r', 'AU17_r']])
    y_predicted

    df['cluster'] = y_predicted

    dwn = df[['Result', 'AU09_r', 'AU10_r', 'AU17_r', 'cluster']].copy()
    dwn.to_csv('DisgustEmotionClustered.csv')

    # Visualize the variations of disgust AU with emotion levels.

    def plot_variations():
        # create figure and axis objects with subplots()
        fig, ax = plt.subplots()
        # make a plot
        ax.plot(df['Result'], df["AU09_r"], color="red", label='AU09')
        ax.plot(df['Result'], df["AU10_r"], color="yellow", label='AU10')
        ax.plot(df['Result'], df["AU17_r"], color="green", label='AU17')

        # set x-axis label
        ax.set_xlabel("Frame", fontsize=14)
        # set y-axis label
        ax.set_ylabel("AU Intensity", color="red", fontsize=14)

        plt.legend()

        # twin object for two different y-axis on the sample plot
        ax2 = ax.twinx()
        # make a plot with different y-axis using second axis object
        ax2.plot(df['Result'], df["cluster"], color="blue", marker="o")
        ax2.set_ylabel("Emotion Level", color="blue", fontsize=14)
        plt.show()
        # save the plot as a file
        fig.savefig('DisgustVariation_plot.jpg',
                    format='jpeg',
                    dpi=100,
                    bbox_inches='tight')

    plot_variations()

# Define the K means algorithm to cluster surprise frames of video.
def surpriseclusteralgorithm():
    df = pd.read_csv("FinalVideoAU.csv")
    df.head()

    sse = []
    k_rng = range(1, 10)
    # just going through 1 to 9
    for k in k_rng:
        # in each iteration create a new model with clusters = k
        km = KMeans(n_clusters=k)

        # Cluster using EFA AU showing variation for Happy emotion levels.
        km.fit(df[['AU01_r', 'AU02_r', 'AU05_r']])

        # inertia will give the sse
        sse.append(km.inertia_)

        # Visualize elbow variations to evaluate the number of clusters.
        def plotElbow():
            plt.xlabel('K')
            plt.ylabel('Sum of squared error')
            plt.plot(k_rng, sse)
    plotElbow()

    km = KMeans(3)
    km
    y_predicted = km.fit_predict(df[['AU01_r', 'AU02_r', 'AU05_r']])
    label = km.predict(df[['AU01_r', 'AU02_r', 'AU05_r']])
    y_predicted

    df['cluster'] = y_predicted

    dwn = df[['Result', 'AU01_r', 'AU02_r', 'AU05_r', 'cluster']].copy()
    dwn.to_csv('SurpriseEmotionClustered.csv')

    # Visualize the variations of Happy AU with emotion levels.

    def plot_variations():
        # create figure and axis objects with subplots()
        fig, ax = plt.subplots()
        # make a plot
        ax.plot(df['Result'], df["AU01_r"], color="red", label='AU01')
        ax.plot(df['Result'], df["AU02_r"], color="yellow", label='AU02')
        ax.plot(df['Result'], df["AU05_r"], color="green", label='AU05')

        # set x-axis label
        ax.set_xlabel("Frame", fontsize=14)
        # set y-axis label
        ax.set_ylabel("AU Intensity", color="red", fontsize=14)

        plt.legend()

        # twin object for two different y-axis on the sample plot
        ax2 = ax.twinx()
        # make a plot with different y-axis using second axis object
        ax2.plot(df['Result'], df["cluster"], color="blue", marker="o")
        ax2.set_ylabel("Emotion Level", color="blue", fontsize=14)
        plt.show()
        # save the plot as a file
        fig.savefig('SurpriseVariation_plot.jpg',
                    format='jpeg',
                    dpi=100,
                    bbox_inches='tight')
    plot_variations()





