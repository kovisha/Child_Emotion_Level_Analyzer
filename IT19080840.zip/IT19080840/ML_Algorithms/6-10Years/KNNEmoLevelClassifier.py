# Import packages

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.model_selection import RandomizedSearchCV
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import plot_confusion_matrix


def KNNClassifier():
    # Import labelled data set
    data = pd.read_csv("/Happy_Sad_Surpris_Disgust-6to10LabelledData.csv")

    df = data[
        ["frame", "AU06_r", "AU07_r", "AU09_r", "AU23_r", "AU14_r", "AU12_r", "AU10_r", "AU04_r", "AU15_r", "AU17_r",
         "AU02_r", "AU25_r", "AU26_r", "cluster"]]

    X = df[
        ["AU06_r", "AU07_r", "AU09_r", "AU23_r", "AU14_r", "AU12_r", "AU10_r", "AU04_r", "AU15_r", "AU17_r", "AU02_r",
         "AU25_r", "AU26_r"]]

    y = df["cluster"]

    data.head()

    # Splitting the data into train and test

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=5)

    # Feature scaling

    sc = StandardScaler()

    X_train = sc.fit_transform(X_train)
    X_test = sc.transform(X_test)

    # fit the KNN model

    classifier = KNeighborsClassifier(n_neighbors=3)

    # Train the model using the training sets
    classifier.fit(X_train, y_train)

    # Predicting the test set results

    y_pred = classifier.predict(X_test)

    # Making the confusion matrix

    cm = confusion_matrix(y_test, y_pred)

    accuracy = accuracy_score(y_test, y_pred)
    accuracy

    classifier.get_params()

    #  Applying Grid Search to find the best model and the best parameters

    k = np.random.randint(1, 50, 60)

    params = {'n_neighbors': k}

    random_search = RandomizedSearchCV(classifier, params, n_iter=5, cv=5, n_jobs=-1, verbose=0)
    random_search.fit(X_train, y_train)

    print("train score : " + str(random_search.score(X_train, y_train)))
    print("test score : " + str(random_search.score(X_test, y_test)))

    print(random_search.best_params_)

    # fit the KNN model again with tuned parameter

    classifier = KNeighborsClassifier(n_neighbors=8)

    # Train the model using the training sets
    classifier.fit(X_train, y_train)

    # Predicting the test set results

    y_pred = classifier.predict(X_test)

    accuracy = accuracy_score(y_test, y_pred)
    accuracy

    fig, ax = plt.subplots(figsize=(22, 22))
    plot_confusion_matrix(classifier, X_test, y_test, cmap='Blues', normalize='true', ax=ax);
    plt.savefig("6-10YearsAllEmotionCMKNNHTwithNeutral")
    # display_labels=['LowHappy','ModHappy','HighHappy','LowSad','ModSad','HighSad','LowDisgust','ModDisgust','HighDisgust']
