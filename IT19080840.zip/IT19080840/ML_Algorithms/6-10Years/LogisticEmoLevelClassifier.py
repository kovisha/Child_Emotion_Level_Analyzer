# Import Packages

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.model_selection import GridSearchCV
import warnings

def LogRegressor():
    # Import Labelled data

    data = pd.read_csv("/Happy_Sad_Surpris_Disgust-6to10LabelledData.csv")

    df = data[
        ["frame", "AU06_r", "AU07_r", "AU09_r", "AU23_r", "AU14_r", "AU12_r", "AU10_r", "AU04_r", "AU15_r", "AU17_r",
         "AU02_r", "AU25_r", "AU26_r", "cluster"]]

    X = df[
        ["AU06_r", "AU07_r", "AU09_r", "AU23_r", "AU14_r", "AU12_r", "AU10_r", "AU04_r", "AU15_r", "AU17_r", "AU02_r",
         "AU25_r", "AU26_r"]]

    y = df["cluster"]

    data.head()

    # Splitting the data into train and test

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=5)

    # Feature scaling

    sc = StandardScaler()

    X_train = sc.fit_transform(X_train)
    X_test = sc.transform(X_test)

    model = LogisticRegression()
    model.fit(X_train, y_train)
    model.score(X_test, y_test)

    # Predicting the test set results

    y_pred = model.predict(X_test)

    # Making the confusion matrix

    cm = confusion_matrix(y_test, y_pred)

    accuracy = accuracy_score(y_test, y_pred)
    accuracy

    warnings.filterwarnings('ignore')  # parameter grid
    parameters = {
        'penalty': ['l1', 'l2'],
        'C': np.logspace(-3, 3, 7),
        'solver': ['newton-cg', 'lbfgs', 'liblinear'],
    }

    # Fit the model with hyper parameters

    model = LogisticRegression()
    clf = GridSearchCV(model,  # model
                       param_grid=parameters,  # hyper parameters
                       scoring='accuracy',  # metric for scoring
                       cv=10)  # number of folds

    # Refit model with tuned parameters
    clf.fit(X_train, y_train)

    # Accuracy after tuning parameter
    print("Tuned Hyper parameters :", clf.best_params_)
    print("Accuracy :", clf.best_score_)
