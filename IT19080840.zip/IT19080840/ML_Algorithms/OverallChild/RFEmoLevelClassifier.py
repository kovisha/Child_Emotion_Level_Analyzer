# import packages

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score

from sklearn.model_selection import RandomizedSearchCV
from scipy.stats import randint

# ------------------------------------ Defining the RF classifier --------------------------------- #

def RFClassifier():
    # Import labelled data
    data = pd.read_csv("/OverallChildHappy_Sad_Disgust_Surprise_Neutral.csv")

    df = data[
        ["frame", "AU01_r", "AU02_r", "AU05_r", "AU04_r", "AU15_r", "AU06_r", "AU07_r", "AU10_r", "AU12_r", "AU25_r",
         "AU09_r", "AU17_r", "cluster"]]

    X = df[
        ["AU01_r", "AU02_r", "AU05_r", "AU04_r", "AU15_r", "AU06_r", "AU07_r", "AU10_r", "AU12_r", "AU25_r", "AU09_r",
         "AU17_r"]]

    y = df["cluster"]

    # Splitting the data into train and test

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=5)

    # Feature scaling

    sc = StandardScaler()

    X_train = sc.fit_transform(X_train)
    X_test = sc.transform(X_test)

    # Fitting Random Forest Classification to the Training set

    classifier = RandomForestClassifier(n_estimators=15, criterion='entropy', random_state=42, class_weight="balanced")
    classifier.fit(X_train, y_train)

    # Predicting the test set results

    y_pred = classifier.predict(X_test)

    # Making the confusion matrix

    cm = confusion_matrix(y_test, y_pred)

    # Accuracy before tuning
    accuracy = accuracy_score(y_test, y_pred)
    print("Accuracy Before tuning: ", accuracy)

    # Estimate the RF classifier to find the best parameters.
    est = RandomForestClassifier(n_jobs=-1)

    rf_p_dist = {"max_depth": [3, 5, 10, None],
                 "n_estimators": [100, 200, 300, 400, 500],
                 "max_features": randint(1, 3),
                 "min_samples_leaf": randint(1, 4),
                 "bootstrap": [True, False],
                 "criterion": ["gini", "entropy"]}

    # Seeking the best parameters
    rf_parameters, rf_ht_score = hypertuning_rscv(est, rf_p_dist, 40, X, y)

    # Fitting the model with tuned best parameters.
    classifier = RandomForestClassifier(n_estimators=400, criterion='entropy', bootstrap=False, max_depth=10,
                                        max_features=1, min_samples_leaf=1)
    classifier.fit(X_train, y_train)

    # Accuracy after tuning
    accuracy = accuracy_score(y_test, y_pred)
    print("Accuracy after tuning: ", accuracy)

# Function completing the Hyper parameter tuning via Random search CV

def hypertuning_rscv(est, p_distr, nbr_iter, X, y):
    rdmsearch = RandomizedSearchCV(est, param_distributions=p_distr,
                                   n_jobs=-1, n_iter=nbr_iter, cv=9)
    rdmsearch.fit(X, y)
    ht_params = rdmsearch.best_params_
    ht_score = rdmsearch.best_score_
    return ht_params, ht_score

