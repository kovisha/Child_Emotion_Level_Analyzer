# import packages

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# ------------------------------------ Defining the Logistic regressor  --------------------------------- #

def LogisticRegressor():
    # Import labelled data
    data = pd.read_csv("/OverallChildHappy_Sad_Disgust_Surprise_Neutral.csv")

    df = data[["AU01_r", "AU02_r", "AU05_r", "AU04_r", "AU15_r", "AU06_r", "AU07_r", "AU10_r", "AU12_r", "AU25_r", "AU09_r",
               "AU17_r", "cluster"]]

    X = df[["AU01_r", "AU02_r", "AU05_r", "AU04_r", "AU15_r", "AU06_r", "AU07_r", "AU10_r", "AU12_r", "AU25_r", "AU09_r",
            "AU17_r"]]

    y = df["cluster"]

    # Splitting the data into train and test

    from sklearn.model_selection import train_test_split

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=5)

    # Feature scaling

    from sklearn.preprocessing import StandardScaler

    sc = StandardScaler()

    X_train = sc.fit_transform(X_train)
    X_test = sc.transform(X_test)

    from sklearn.linear_model import LogisticRegression

    model = LogisticRegression()
    model.fit(X_train, y_train)
    model.score(X_test, y_test)

    # Predicting the test set results

    y_pred = model.predict(X_test)

    # Making the confusion matrix

    from sklearn.metrics import confusion_matrix

    cm = confusion_matrix(y_test, y_pred)

    from sklearn.metrics import accuracy_score

    # Accuracy before tuning
    accuracy = accuracy_score(y_test, y_pred)
    accuracy

    model.get_params().keys()

    from sklearn.model_selection import GridSearchCV
    import warnings

    warnings.filterwarnings('ignore')  # parameter grid
    parameters = {
        'penalty': ['l1', 'l2'],
        'C': np.logspace(-3, 3, 7),
        'solver': ['newton-cg', 'lbfgs', 'liblinear'],
    }

    # Tuning the model via Grid Search CV
    model = LogisticRegression()
    clf = GridSearchCV(model,  # model
                       param_grid=parameters,  # hyper parameters
                       scoring='accuracy',  # metric for scoring
                       cv=10)  # number of folds

    # Train the model using the training sets
    clf.fit(X_train, y_train)

    # Accuracy After hyperparameter tuning.
    print("Tuned Hyper parameters :", clf.best_params_)
    print("Accuracy :", clf.best_score_)
