# import packages

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
import numpy as np

from sklearn.model_selection import RandomizedSearchCV


# ------------------------------------ Defining the KNN classifier --------------------------------- #

def KNNClassifier():
    # Import labelled data
    data = pd.read_csv("/OverallChildHappy_Sad_Disgust_Surprise_Neutral.csv")

    df = data[
        ["frame", "AU01_r", "AU02_r", "AU05_r", "AU04_r", "AU15_r", "AU06_r", "AU07_r", "AU10_r", "AU12_r", "AU25_r",
         "AU09_r", "AU17_r", "cluster"]]

    X = df[
        ["AU01_r", "AU02_r", "AU05_r", "AU04_r", "AU15_r", "AU06_r", "AU07_r", "AU10_r", "AU12_r", "AU25_r", "AU09_r",
         "AU17_r"]]

    y = df["cluster"]

    # Splitting the data into train and test

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=5)

    # Feature scaling

    sc = StandardScaler()

    X_train = sc.fit_transform(X_train)
    X_test = sc.transform(X_test)

    # Fitting KNN Classification to the Training set

    classifier = KNeighborsClassifier(n_neighbors=3)

    classifier.fit(X_train, y_train)

    # Predicting the test set results

    y_pred = classifier.predict(X_test)

    # Making the confusion matrix

    cm = confusion_matrix(y_test, y_pred)

    # Accuracy before tuning
    accuracy = accuracy_score(y_test, y_pred)
    print("Accuracy Before tuning: ", accuracy)

    # Finding the feasible K values for the KNN classifier.
    k = np.random.randint(1, 50, 60)

    params = {'n_neighbors': k}

    # Tuning the model via Random Search CV

    random_search = RandomizedSearchCV(classifier, params, n_iter=5, cv=5, n_jobs=-1, verbose=0)
    random_search.fit(X_train, y_train)

    print("train score : " + str(random_search.score(X_train, y_train)))
    print("test score : " + str(random_search.score(X_test, y_test)))

    # Re fitting the KNN classifier.
    classifier = KNeighborsClassifier(n_neighbors=1)

    # Train the model using the training sets
    classifier.fit(X_train, y_train)

    # Accuracy After hyperparameter tuning.
    accuracy = accuracy_score(y_test, y_pred)
    print("Accuracy after tuning: ", accuracy)
