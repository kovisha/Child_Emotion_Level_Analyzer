# import packages

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score

from sklearn.model_selection import GridSearchCV

# ------------------------------------ Defining the SVM classifier --------------------------------- #

def SVMClassifier():
    # Import labelled data
    data = pd.read_csv("/4-6YearEmotionlevelAnnotatedData.csv")

    df = data[
        ["frame", "AU09_r", "AU10_r", "AU06_r", "AU12_r", "AU17_r", "AU23_r", "AU05_r", "AU01_r", "AU02_r", "cluster"]]

    X = df[
        ["AU09_r", "AU10_r", "AU06_r", "AU12_r", "AU17_r", "AU23_r", "AU05_r", "AU01_r", "AU02_r"]]

    y = df["cluster"]

    # Splitting the data into train and test

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=5)

    # Feature scaling

    sc = StandardScaler()

    X_train = sc.fit_transform(X_train)
    X_test = sc.transform(X_test)

    # Fitting SVM Classification to the Training set

    classifier = SVC(kernel='linear', random_state=0)
    classifier.fit(X_train, y_train)

    # Predicting the test set results

    y_pred = classifier.predict(X_test)

    # Making the confusion matrix

    cm = confusion_matrix(y_test, y_pred)

    # Accuracy before tuning
    accuracy = accuracy_score(y_test, y_pred)
    print("Accuracy Before tuning: ", accuracy)

    # Finding the best parameters

    parameters = [{'C': [1, 10, 100, 1000], 'kernel': ['linear']},
                  {'C': [1, 10, 100, 1000], 'kernel': ['rbf'], 'gamma': [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]}]
    grid_search = GridSearchCV(estimator=classifier,
                               param_grid=parameters,
                               scoring='accuracy',
                               cv=10,
                               n_jobs=-1)

    # Finding the best parameter
    grid_search = grid_search.fit(X_train, y_train)

    grid_search.best_params_

    # Re fitting the model with tuned parameters.
    classifier = SVC(kernel='rbf', gamma=0.4, C=1000)
    classifier.fit(X_train, y_train)

    # Accuracy after tuning
    accuracy = accuracy_score(y_test, y_pred)
    print("Accuracy after tuning: ", accuracy)

