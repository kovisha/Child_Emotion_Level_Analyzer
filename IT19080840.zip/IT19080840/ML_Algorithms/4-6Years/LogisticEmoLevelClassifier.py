# Import packages

import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.model_selection import GridSearchCV
import warnings

# ------------------------------------ Defining the Logistic regressor --------------------------------- #

def LogRegressor():
    # Import labelled data
    data = pd.read_csv("/4-6YearEmotionlevelEncodedData.csv")

    df = data[["AU09_r", "AU10_r", "AU06_r", "AU12_r", "AU17_r", "AU23_r", "AU05_r", "AU01_r", "AU02_r", "cluster"]]

    X = df[["AU09_r", "AU10_r", "AU06_r", "AU12_r", "AU17_r", "AU23_r", "AU05_r", "AU01_r", "AU02_r"]]

    y = df["cluster"]

    data.head()

    # Splitting the data into train and test

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=5)

    # Feature scaling

    sc = StandardScaler()

    X_train = sc.fit_transform(X_train)
    X_test = sc.transform(X_test)

    # Model fitting
    model = LogisticRegression()
    model.fit(X_train, y_train)

    # Model score
    model.score(X_test, y_test)

    # Predicting the test set results

    y_pred = model.predict(X_test)

    # Making the confusion matrix

    cm = confusion_matrix(y_test, y_pred)

    accuracy = accuracy_score(y_test, y_pred)
    accuracy

    warnings.filterwarnings('ignore')  # parameter grid
    parameters = {
        'penalty': ['l1', 'l2'],
        'C': np.logspace(-3, 3, 7),
        'solver': ['newton-cg', 'lbfgs', 'liblinear'],
    }

    # Tuning the model with Grid Search CV
    model = LogisticRegression()
    clf = GridSearchCV(model,  # model
                       param_grid=parameters,  # hyper parameters
                       scoring='accuracy',  # metric for scoring
                       cv=10)  # number of folds

    # Train model with tuned parameters
    clf.fit(X_train, y_train)

    # Accuracy after tuning
    print("Tuned Hyper parameters :", clf.best_params_)
    print("Accuracy :", clf.best_score_)
