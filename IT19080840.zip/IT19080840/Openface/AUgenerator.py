from MSA_FET import FeatureExtractionTool, get_default_config
import pickle as pkl
import pandas as pd
import logging

formatter = logging.Formatter(
    '%(asctime)s %(levelname)s %(message)s', datefmt="%Y-%m-%d %H:%M:%S"
)
handler = logging.FileHandler('Logs\\ErrorLog.log', mode='a')
handler.setFormatter(formatter)
logger = logging.getLogger("logger_name")
logger.setLevel(logging.INFO)
logger.addHandler(handler)

config_v = get_default_config('openface')

from Classifier import predictLevelsRF


# Define function to convert pickle to csv

def convertPickle(file, category):
    # Open the pkl file generated

    with open(file, "rb") as f:

        # Feature file stored as a dictionary

        feature_object = pkl.load(f)

    # separate the keys and values from dictionary

    keys = []
    values = []
    items = feature_object.items()
    for item in items:
        keys.append(item[0]), values.append(item[1])

    # Define a new dataframe to obtain only AU intensities

    AU = pd.DataFrame(values[0])

    AUIntensities = AU.iloc[:, 142: 159].copy()

    # Defining the type of AU features required based on the age category

    if category == "1":
        AUIntensities.columns = [" AU01_r", " AU02_r", " AU04_r", " AU05_r", " AU06_r", " AU07_r", " AU09_r", " AU10_r",
                                 " AU12_r",
                                 " AU14_r", " AU15_r", " AU17_r", " AU20_r", " AU23_r", " AU25_r", " AU26_r", " AU45_r"]

        AUIntensities.to_csv("Openface/AUFeatures.csv")
        logger.info("Feature file for overall child analysis created!")

    elif category == "2":
        AUIntensities.columns = [" AU09_r", " AU10_r", " AU06_r", " AU12_r", " AU17_r", " AU23_r", " AU05_r", " AU01_r",
                                 "AU02_r"]

        AUIntensities.to_csv("Openface/AUFeatures.csv")
        logger.info("Feature file for 4-6 year child analysis created!")

    elif category == "3":
        AUIntensities.columns = [" AU06_r", " AU07_r", " AU09_r", " AU23_r", " AU14_r", " AU12_r", " AU10_r", " AU04_r",
                                 " AU15_r", " AU17_r", " AU02_r", " AU25_r", " AU26_r"]

        AUIntensities.to_csv("Openface/AUFeatures.csv")
        logger.info("Feature file for 6-10 year child analysis created!")

    else:
        logger.error("Incorrect category! Recheck input.")


# Define the function to capture media and produce AU files.

def videocapture(file_path, category):
    logger.info("Starting Openface Detection")

    fet = FeatureExtractionTool("openface")

    try:
        feature = fet.run_single(file_path)
        logger.info(feature)

    except FileNotFoundError as e:
        print(e.strerror)

    fet = FeatureExtractionTool(config_v, tmp_dir="/tmp")

    fet.run_single(in_file=file_path, out_file="feature.pkl", text_file="input.txt")
    logger.info("Feature pickle file generated.")
    logger.info("OpenFace AU detection completed")

    # Convert the pkl file created into a csv file of AU intensities.

    logger.info("Calling Feature pickle converter")
    convertPickle("Openface/feature.pkl", category)

    logger.info("Begin Emotion level prediction")
    predictLevelsRF.predictEmoLevel(category, "Openface/AUFeatures.csv")
